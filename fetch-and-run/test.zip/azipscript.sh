#!/bin/bash


echo This is my script that lives inside a zip file.

echo Now I will display the contents of another file in the zip.

cat someotherfile.txt

echo "That's it! I'm out of here!"

